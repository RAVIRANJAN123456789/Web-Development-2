function click(n){
            var click=document.createElement('button');
            btn.addEventListener("click",function(){click.HTML++});
            
        }
}